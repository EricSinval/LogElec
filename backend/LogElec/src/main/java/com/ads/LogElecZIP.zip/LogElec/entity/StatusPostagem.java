package com.ads.LogElec.entity;

public enum StatusPostagem {
    ABERTA,
    CANCELADA,
    FINALIZADA
}