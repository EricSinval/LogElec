package com.ads.LogElec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogElecApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogElecApplication.class, args);
	}

}
