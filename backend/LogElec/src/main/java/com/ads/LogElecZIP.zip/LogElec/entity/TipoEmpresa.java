package com.ads.LogElec.entity;

public enum TipoEmpresa {
    DESCARTE,
    COLETA
}