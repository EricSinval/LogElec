package com.ads.LogElec.entity;

public enum StatusAgendamento {
    AGENDADA,
    CONFIRMADA,
    CANCELADA,
    REALIZADA
}